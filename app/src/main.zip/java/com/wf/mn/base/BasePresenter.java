package com.wf.mn.base;

/**
 * @author : wf
 * @time : 2020-11-10-10:49
 */
public class BasePresenter<T extends BaseIView> {

    public BasePresenter() {
    }

    public T iView;
    public void initViewModel(T t){
        this.iView = t;
    }

//    当页面销毁得时候，需要解除view得关联

    public void ditcahView(){
        iView = null;
    }
}
