package com.wf.mn.base;

/**
 * @author : wf
 * @time : 2020-11-10-10:50
 */
public interface BaseIView {
}
